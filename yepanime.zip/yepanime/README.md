# YepAnime

Situs streaming anime berbasis Next.js 14 (App Router), TypeScript, Tailwind CSS, dan Cheerio.

## Menjalankan lokal

```
npm install
npm run dev
```

## Deploy ke Vercel

1. Unggah folder ini ke repositori GitHub.
2. Impor repositori di Vercel. Framework terdeteksi otomatis sebagai Next.js.
3. Klik Deploy. Tidak ada environment variable yang diperlukan.

Atau lewat CLI: `npx vercel --prod`.
