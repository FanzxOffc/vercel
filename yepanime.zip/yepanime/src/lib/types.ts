export type InfoMap = Record<string, string>;

export interface HomeAnime {
  title: string;
  link: string;
  thumb: string;
  episode: string;
  date: string;
}

export interface SearchResult {
  title: string;
  link: string;
  thumb: string;
  info: InfoMap;
}

export interface EpisodeItem {
  title: string;
  date: string;
  link: string;
}

export interface AnimeDetail {
  title: string;
  thumb: string;
  synopsis: string;
  info: InfoMap;
  episodes: EpisodeItem[];
}

export interface MirrorLink {
  provider: string;
  encoded: string;
}

export interface MirrorGroup {
  quality: string;
  links: MirrorLink[];
}

export interface StreamData {
  title: string;
  defaultStream: string | null;
  isMaintenance: boolean;
  mirrors: MirrorGroup[];
}

export interface ResolveResult {
  iframe: string | null;
}

export interface DownloadLink {
  provider: string;
  url: string;
}

export interface DownloadGroup {
  format: string;
  links: DownloadLink[];
}

export interface DownloadData {
  title: string;
  downloads: DownloadGroup[];
}

export interface EpisodeNavigation {
  prev: string | null;
  next: string | null;
  all: string | null;
}

export interface HistoryEntry {
  slug: string;
  title: string;
  watchedAt: number;
}
