import type { HistoryEntry } from "./types";

const STORAGE_KEY = "yepanime:history";
const MAX_ENTRIES = 30;

const isEntry = (value: unknown): value is HistoryEntry => {
  if (typeof value !== "object" || value === null) {
    return false;
  }
  const candidate = value as Record<string, unknown>;
  return (
    typeof candidate.slug === "string" &&
    typeof candidate.title === "string" &&
    typeof candidate.watchedAt === "number"
  );
};

export const readHistory = (): HistoryEntry[] => {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return [];
    }
    const parsed: unknown = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as unknown[]).filter(isEntry) : [];
  } catch {
    return [];
  }
};

export const pushHistory = (entry: HistoryEntry): void => {
  try {
    const next = [entry, ...readHistory().filter((item) => item.slug !== entry.slug)].slice(
      0,
      MAX_ENTRIES
    );
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  } catch {
    return;
  }
};

export const clearHistory = (): void => {
  try {
    window.localStorage.removeItem(STORAGE_KEY);
  } catch {
    return;
  }
};
