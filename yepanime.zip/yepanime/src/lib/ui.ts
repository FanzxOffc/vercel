export type ButtonVariant = "primary" | "success" | "danger" | "secondary" | "info";

const buttonBase =
  "inline-flex min-h-[44px] items-center justify-center gap-2 rounded-full px-5 text-sm font-medium shadow-soft transition-all duration-300 disabled:cursor-not-allowed disabled:opacity-50";

const buttonVariants: Record<ButtonVariant, string> = {
  primary:
    "border border-red-500/50 bg-accent text-white hover:bg-accent-hover hover:shadow-glow",
  success: "border border-green-500/20 bg-green-500/10 text-green-400 hover:bg-green-500/20",
  danger: "border border-red-500/20 bg-red-500/10 text-red-400 hover:bg-red-500/20",
  secondary: "border border-white/10 bg-surface text-gray-400 hover:bg-[#222] hover:text-white",
  info: "border border-blue-500/20 bg-blue-500/10 text-blue-400 hover:bg-blue-500/20",
};

export const buttonClass = (variant: ButtonVariant, extra: string = ""): string =>
  [buttonBase, buttonVariants[variant], extra].filter(Boolean).join(" ");

export const cardClass =
  "overflow-hidden rounded-xl border border-red-500/10 bg-surface shadow-card";

export const badgeClasses = {
  ongoing:
    "rounded-full border border-green-500/20 bg-green-500/10 px-3 py-1 font-mono text-xs text-green-400",
  completed:
    "rounded-full border border-blue-500/20 bg-blue-500/10 px-3 py-1 font-mono text-xs text-blue-400",
  episode: "rounded-md bg-accent px-2 py-1 font-mono text-xs text-white shadow-lg",
};

export const inputClass =
  "min-h-[44px] w-full rounded-full border border-white/10 bg-base px-5 text-sm text-ink placeholder:text-muted focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/30";

export const gridClass = "grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-5";
