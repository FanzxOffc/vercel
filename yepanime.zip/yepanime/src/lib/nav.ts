import type { IconDefinition } from "@fortawesome/fontawesome-svg-core";
import {
  faClockRotateLeft,
  faHouse,
  faMagnifyingGlass,
  faUser,
} from "@fortawesome/free-solid-svg-icons";

export interface NavItem {
  href: string;
  label: string;
  icon: IconDefinition;
}

export const navItems: NavItem[] = [
  { href: "/", label: "Beranda", icon: faHouse },
  { href: "/search", label: "Cari", icon: faMagnifyingGlass },
  { href: "/history", label: "Riwayat", icon: faClockRotateLeft },
  { href: "/profile", label: "Profil", icon: faUser },
];
