const BASE_HOST = "otakudesu.blog";
const slugPattern = /^[a-z0-9][a-z0-9-]{0,200}$/i;

export type UpstreamKind = "anime" | "episode" | "batch";

export const isValidSlug = (slug: string): boolean => slugPattern.test(slug);

export const upstreamUrl = (kind: UpstreamKind, slug: string): string =>
  `https://${BASE_HOST}/${kind}/${slug}/`;

export const slugFromLink = (link: string): string => {
  try {
    const segments = new URL(link).pathname.split("/").filter(Boolean);
    return segments[segments.length - 1] ?? "";
  } catch {
    return "";
  }
};

export const internalPath = (link: string): string => {
  const slug = slugFromLink(link);
  if (link.includes("/episode/")) {
    return `/episode/${slug}`;
  }
  if (link.includes("/batch/")) {
    return `/batch/${slug}`;
  }
  return `/anime/${slug}`;
};

export const isSafeHttpUrl = (value: string): boolean => {
  try {
    const parsed = new URL(value);
    return parsed.protocol === "https:" || parsed.protocol === "http:";
  } catch {
    return false;
  }
};

export const episodeLabel = (title: string): string => {
  const match = title.match(/episode\s+([0-9]+(?:\.[0-9]+)?)/i);
  return match ? `Eps ${match[1]}` : title;
};

export const normalizeQuality = (value: string): string => {
  const match = value.match(/\d{3,4}p/i);
  return match ? match[0].toLowerCase() : value;
};
