interface Bucket {
  count: number;
  resetAt: number;
}

export interface RateVerdict {
  allowed: boolean;
  retryAfter: number;
}

const createRateLimiter = (limit: number, windowMs: number) => {
  const buckets = new Map<string, Bucket>();

  return (key: string): RateVerdict => {
    const now = Date.now();

    if (buckets.size > 5000) {
      buckets.forEach((bucket, bucketKey) => {
        if (bucket.resetAt <= now) {
          buckets.delete(bucketKey);
        }
      });
    }

    const current = buckets.get(key);
    if (!current || current.resetAt <= now) {
      buckets.set(key, { count: 1, resetAt: now + windowMs });
      return { allowed: true, retryAfter: 0 };
    }

    current.count += 1;
    if (current.count > limit) {
      return { allowed: false, retryAfter: Math.ceil((current.resetAt - now) / 1000) };
    }
    return { allowed: true, retryAfter: 0 };
  };
};

export const apiLimiter = createRateLimiter(60, 60000);
