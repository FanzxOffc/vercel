import { load } from "cheerio";
import type {
  AnimeDetail,
  DownloadData,
  DownloadGroup,
  DownloadLink,
  EpisodeItem,
  EpisodeNavigation,
  HomeAnime,
  InfoMap,
  MirrorGroup,
  MirrorLink,
  ResolveResult,
  SearchResult,
  StreamData,
} from "./types";

const BASE_URL = "https://otakudesu.blog";
const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
const NONCE_ACTION = "aa1208d27f29ca340c92c66d1926f13f";
const IFRAME_ACTION = "2a3505c93b0035d3f455df82bf976b84";
const REQUEST_TIMEOUT_MS = 12000;
const HOME_LIMIT = 12;

interface AjaxResponse {
  data?: string;
}

const cleanUrl = (url: string): string => url.replace(/[\s",']+$/g, "");

const isTrustedUrl = (url: string): boolean => {
  try {
    const parsed = new URL(url);
    return parsed.protocol === "https:" && parsed.hostname === new URL(BASE_URL).hostname;
  } catch {
    return false;
  }
};

const assertUrl = (rawUrl: string, allowedSegments: string[]): string => {
  const url = cleanUrl(rawUrl);
  const hasSegment = allowedSegments.some((segment) => url.includes(segment));
  if (!hasSegment || !isTrustedUrl(url)) {
    throw new Error("URL tidak valid.");
  }
  return url;
};

const fetchHtml = async (url: string): Promise<string> => {
  const res = await fetch(url, {
    headers: { "User-Agent": UA },
    signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
    next: { revalidate: 300 },
  });
  if (!res.ok) {
    throw new Error(`HTTP ${res.status} - ${url}`);
  }
  return res.text();
};

const postAjax = async <T>(targetUrl: string, params: Record<string, string>): Promise<T> => {
  const res = await fetch(`${BASE_URL}/wp-admin/admin-ajax.php`, {
    method: "POST",
    headers: {
      "User-Agent": UA,
      "Content-Type": "application/x-www-form-urlencoded",
      Referer: targetUrl,
    },
    body: new URLSearchParams(params),
    signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
    cache: "no-store",
  });
  if (!res.ok) {
    throw new Error(`HTTP ${res.status} - admin-ajax`);
  }
  return (await res.json()) as T;
};

const splitKeyValue = (text: string): [string, string] | null => {
  const parts = text.trim().split(":");
  if (parts.length < 2) {
    return null;
  }
  return [parts[0].trim(), parts.slice(1).join(":").trim()];
};

const decodeBase64 = (value: string): string => Buffer.from(value, "base64").toString("utf8");

const parsePayload = (encoded: string): Record<string, string> => {
  const parsed: unknown = JSON.parse(decodeBase64(encoded));
  if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
    throw new Error("Data mirror tidak valid.");
  }
  return Object.fromEntries(
    Object.entries(parsed as Record<string, unknown>).map(([key, value]) => [key, String(value)])
  );
};

const extractIframeSrc = (markup: string): string => {
  const $ = load(markup);
  return $("iframe").attr("src") ?? markup;
};

const homeUrl = (page: number): string =>
  page <= 1 ? BASE_URL : `${BASE_URL}/ongoing-anime/page/${page}/`;

export const getHomeAnime = async (
  page: number = 1,
  limit: number = HOME_LIMIT
): Promise<HomeAnime[]> => {
  const html = await fetchHtml(homeUrl(page));
  const $ = load(html);
  const results: HomeAnime[] = [];

  $(".venz")
    .first()
    .find("ul li")
    .each((_, el) => {
      const title = $(el).find(".jdlflm").text().trim();
      const link = $(el).find("a").first().attr("href") ?? "";
      const thumb = $(el).find("img").first().attr("src") ?? "";
      const episode = $(el).find(".epz").text().trim();
      const date = $(el).find(".newnime").text().trim();
      if (title && link) {
        results.push({ title, link, thumb, episode, date });
      }
    });

  return results.slice(0, limit);
};

export const searchAnime = async (query: string): Promise<SearchResult[]> => {
  const url = `${BASE_URL}/?s=${encodeURIComponent(query)}&post_type=anime`;
  const html = await fetchHtml(url);
  const $ = load(html);
  const results: SearchResult[] = [];

  $("ul.chivsrc li").each((_, el) => {
    const title = $(el).find("h2 a").text().trim();
    const link = $(el).find("h2 a").attr("href") ?? "";
    const thumb = $(el).find("img").attr("src") ?? "";
    const info: InfoMap = {};

    $(el)
      .find(".set")
      .each((__, setEl) => {
        const pair = splitKeyValue($(setEl).text());
        if (pair) {
          info[pair[0]] = pair[1];
        }
      });

    if (title && link) {
      results.push({ title, link, thumb, info });
    }
  });

  return results;
};

export const getDetail = async (animeUrl: string): Promise<AnimeDetail> => {
  const url = assertUrl(animeUrl, ["/anime/"]);
  const html = await fetchHtml(url);
  const $ = load(html);
  const info: InfoMap = {};

  $(".infozingle p").each((_, el) => {
    const pair = splitKeyValue($(el).text());
    if (pair) {
      info[pair[0]] = pair[1];
    }
  });

  const episodes: EpisodeItem[] = [];
  $(".episodelist ul li").each((_, el) => {
    const title = $(el).find("a").text().trim();
    const link = $(el).find("a").attr("href") ?? "";
    const date = $(el).find(".zeebr").text().trim();
    if (title && link) {
      episodes.push({ title, date, link });
    }
  });

  const title = $(".jdlrx h1").text().trim() || $("h1").first().text().trim();
  const thumb = $(".fotoanime img").attr("src") ?? "";
  const synopsis = $(".sinopc p").text().trim();

  return { title, thumb, synopsis, info, episodes };
};

export const getStream = async (episodeUrl: string): Promise<StreamData> => {
  const url = assertUrl(episodeUrl, ["/episode/"]);
  const html = await fetchHtml(url);
  const $ = load(html);

  const title = $(".jdlrx h1").text().trim() || $("h1").first().text().trim();
  const defaultStream =
    $(".responsive-embed iframe").attr("src") || $("#pembed iframe").attr("src") || "";
  const isMaintenance = defaultStream.includes("maintenance");
  const mirrors: MirrorGroup[] = [];

  $(".mirrorstream ul").each((_, el) => {
    const quality = $(el).find("span").text().trim() || $(el).attr("class") || "";
    const links: MirrorLink[] = [];

    $(el)
      .find("li a")
      .each((__, a) => {
        const encoded = $(a).attr("data-content");
        if (encoded) {
          links.push({ provider: $(a).text().trim(), encoded });
        }
      });

    if (links.length > 0) {
      mirrors.push({ quality, links });
    }
  });

  return {
    title,
    defaultStream: isMaintenance || !defaultStream ? null : defaultStream,
    isMaintenance,
    mirrors,
  };
};

export const getEpisodeNavigation = async (episodeUrl: string): Promise<EpisodeNavigation> => {
  const url = assertUrl(episodeUrl, ["/episode/"]);
  const html = await fetchHtml(url);
  const $ = load(html);
  const navigation: EpisodeNavigation = { prev: null, next: null, all: null };

  $(".flir a").each((_, el) => {
    const label = $(el).text().trim().toLowerCase();
    const href = $(el).attr("href") ?? "";
    if (href && href !== "#") {
      if (label.includes("prev")) {
        navigation.prev = href;
      } else if (label.includes("next")) {
        navigation.next = href;
      } else {
        navigation.all = href;
      }
    }
  });

  return navigation;
};

export const resolveMirror = async (
  targetUrl: string,
  encodedData: string
): Promise<ResolveResult> => {
  const referer = assertUrl(targetUrl, ["/episode/"]);
  const payload = parsePayload(encodedData);

  const nonceResponse = await postAjax<AjaxResponse>(referer, { action: NONCE_ACTION });
  const nonce = nonceResponse.data ?? "";

  const iframeResponse = await postAjax<AjaxResponse>(referer, {
    ...payload,
    nonce,
    action: IFRAME_ACTION,
  });

  if (iframeResponse.data) {
    return { iframe: extractIframeSrc(decodeBase64(iframeResponse.data)) };
  }
  return { iframe: null };
};

export const getDownload = async (episodeUrl: string): Promise<DownloadData> => {
  const url = assertUrl(episodeUrl, ["/episode/", "/batch/"]);
  const html = await fetchHtml(url);
  const $ = load(html);
  const downloads: DownloadGroup[] = [];

  $(".download ul li").each((_, el) => {
    const format = $(el).find("strong").text().trim();
    const links: DownloadLink[] = [];

    $(el)
      .find("a")
      .each((__, a) => {
        const href = $(a).attr("href");
        if (href && href !== "#") {
          links.push({ provider: $(a).text().trim(), url: href });
        }
      });

    if (format && links.length > 0) {
      downloads.push({ format, links });
    }
  });

  const title = $(".jdlrx h1").text().trim() || $("h1").first().text().trim();

  return { title, downloads };
};
