import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { apiLimiter } from "./rate-limit";

const PUBLIC_CACHE = "public, s-maxage=300, stale-while-revalidate=600";
const INVALID_PARAM = "Parameter tidak valid.";
const CLIENT_ERRORS = new Set<string>([INVALID_PARAM, "URL tidak valid.", "Data mirror tidak valid."]);

const clientKey = (request: NextRequest): string =>
  (request.headers.get("x-forwarded-for") ?? "anonim").split(",")[0].trim();

const jsonError = (message: string, status: number, extra: Record<string, string> = {}): NextResponse =>
  NextResponse.json(
    { error: message },
    { status, headers: { "Cache-Control": "no-store", ...extra } }
  );

export const requiredParam = (request: NextRequest, name: string, maxLength: number): string => {
  const value = request.nextUrl.searchParams.get(name)?.trim() ?? "";
  if (!value || value.length > maxLength) {
    throw new Error(INVALID_PARAM);
  }
  return value;
};

export const intParam = (
  request: NextRequest,
  name: string,
  fallback: number,
  max: number
): number => {
  const parsed = Number.parseInt(request.nextUrl.searchParams.get(name) ?? "", 10);
  if (Number.isNaN(parsed) || parsed < 1) {
    return fallback;
  }
  return Math.min(parsed, max);
};

export const invalidParam = (): Error => new Error(INVALID_PARAM);

export const withApi = async <T>(
  request: NextRequest,
  task: () => Promise<T>,
  cacheable: boolean
): Promise<NextResponse> => {
  const verdict = apiLimiter(clientKey(request));
  if (!verdict.allowed) {
    return jsonError("Terlalu banyak permintaan. Coba lagi sebentar lagi.", 429, {
      "Retry-After": String(verdict.retryAfter),
    });
  }

  try {
    const data = await task();
    return NextResponse.json(data, {
      headers: { "Cache-Control": cacheable ? PUBLIC_CACHE : "no-store" },
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "";
    if (CLIENT_ERRORS.has(message)) {
      return jsonError(message, 400);
    }
    return jsonError("Gagal mengambil data dari sumber.", 502);
  }
};
