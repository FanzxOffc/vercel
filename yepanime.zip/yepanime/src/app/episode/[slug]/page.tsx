import { cache } from "react";
import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faChevronLeft, faChevronRight, faList } from "@fortawesome/free-solid-svg-icons";
import { DownloadList } from "@/components/download-list";
import { EpisodePlayer } from "@/components/episode-player";
import { HistoryRecorder } from "@/components/history-recorder";
import { getDownload, getEpisodeNavigation, getStream } from "@/lib/scraper";
import type { DownloadData, EpisodeNavigation } from "@/lib/types";
import { buttonClass } from "@/lib/ui";
import { internalPath, isValidSlug, upstreamUrl } from "@/lib/urls";

export const maxDuration = 30;

interface PageProps {
  params: { slug: string };
}

const loadStream = cache(async (slug: string) => getStream(upstreamUrl("episode", slug)).catch(() => null));

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const stream = isValidSlug(params.slug) ? await loadStream(params.slug) : null;
  return { title: stream ? stream.title : "Nonton Episode" };
}

const disabledClass = "pointer-events-none opacity-40";

export default async function EpisodePage({ params }: PageProps) {
  if (!isValidSlug(params.slug)) {
    notFound();
  }

  const episodeUrl = upstreamUrl("episode", params.slug);
  const [stream, download, navigation] = await Promise.all([
    loadStream(params.slug),
    getDownload(episodeUrl).catch((): DownloadData | null => null),
    getEpisodeNavigation(episodeUrl).catch((): EpisodeNavigation | null => null),
  ]);

  if (!stream) {
    notFound();
  }

  const prev = navigation?.prev?.includes("/episode/") ? navigation.prev : null;
  const next = navigation?.next?.includes("/episode/") ? navigation.next : null;
  const all = navigation?.all?.includes("/anime/") ? navigation.all : null;

  return (
    <div className="space-y-8">
      <HistoryRecorder slug={params.slug} title={stream.title} />

      <div className="space-y-3" data-aos="fade-up">
        <h1 className="text-xl font-bold leading-snug text-white sm:text-2xl">{stream.title}</h1>
        {all ? (
          <Link href={internalPath(all)} className={buttonClass("secondary", "text-xs")}>
            <FontAwesomeIcon icon={faList} />
            Semua Episode
          </Link>
        ) : null}
      </div>

      <div data-aos="fade-up" data-aos-delay="80">
        <EpisodePlayer
          episodeUrl={episodeUrl}
          defaultStream={stream.defaultStream}
          isMaintenance={stream.isMaintenance}
          mirrors={stream.mirrors}
        />
      </div>

      <nav className="grid grid-cols-2 gap-3" aria-label="Navigasi episode" data-aos="fade-up">
        {prev ? (
          <Link href={internalPath(prev)} className={buttonClass("secondary")}>
            <FontAwesomeIcon icon={faChevronLeft} />
            Sebelumnya
          </Link>
        ) : (
          <span aria-disabled="true" className={buttonClass("secondary", disabledClass)}>
            <FontAwesomeIcon icon={faChevronLeft} />
            Sebelumnya
          </span>
        )}
        {next ? (
          <Link href={internalPath(next)} className={buttonClass("primary")}>
            Selanjutnya
            <FontAwesomeIcon icon={faChevronRight} />
          </Link>
        ) : (
          <span aria-disabled="true" className={buttonClass("secondary", disabledClass)}>
            Selanjutnya
            <FontAwesomeIcon icon={faChevronRight} />
          </span>
        )}
      </nav>

      <DownloadList groups={download ? download.downloads : []} />
    </div>
  );
}
