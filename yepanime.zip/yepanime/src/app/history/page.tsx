import type { Metadata } from "next";
import { HistoryList } from "@/components/history-list";

export const metadata: Metadata = { title: "Riwayat" };

export default function HistoryPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3" data-aos="fade-up">
        <span className="h-6 w-1 rounded-full bg-accent" />
        <h1 className="text-xl font-semibold text-white">Riwayat Tontonan</h1>
      </div>
      <HistoryList />
    </div>
  );
}
