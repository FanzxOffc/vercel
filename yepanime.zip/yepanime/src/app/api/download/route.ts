import type { NextRequest } from "next/server";
import { getDownload } from "@/lib/scraper";
import { requiredParam, withApi } from "@/lib/api";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

export function GET(request: NextRequest) {
  return withApi(request, () => getDownload(requiredParam(request, "url", 400)), true);
}
