import type { NextRequest } from "next/server";
import { resolveMirror } from "@/lib/scraper";
import { invalidParam, withApi } from "@/lib/api";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

interface ResolveBody {
  url: string;
  encoded: string;
}

const readBody = (value: unknown): ResolveBody | null => {
  if (typeof value !== "object" || value === null) {
    return null;
  }
  const candidate = value as Record<string, unknown>;
  const { url, encoded } = candidate;
  if (typeof url !== "string" || typeof encoded !== "string") {
    return null;
  }
  if (!url || url.length > 400 || !encoded || encoded.length > 4000) {
    return null;
  }
  return { url, encoded };
};

export function POST(request: NextRequest) {
  return withApi(
    request,
    async () => {
      const raw: unknown = await request.json().catch(() => null);
      const body = readBody(raw);
      if (!body) {
        throw invalidParam();
      }
      return resolveMirror(body.url, body.encoded);
    },
    false
  );
}
