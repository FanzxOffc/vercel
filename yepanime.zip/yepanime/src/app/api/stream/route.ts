import type { NextRequest } from "next/server";
import { getStream } from "@/lib/scraper";
import { requiredParam, withApi } from "@/lib/api";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

export function GET(request: NextRequest) {
  return withApi(request, () => getStream(requiredParam(request, "url", 400)), true);
}
