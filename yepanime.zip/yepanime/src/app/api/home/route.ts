import type { NextRequest } from "next/server";
import { getHomeAnime } from "@/lib/scraper";
import { intParam, withApi } from "@/lib/api";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

export function GET(request: NextRequest) {
  const page = intParam(request, "page", 1, 50);
  return withApi(request, () => getHomeAnime(page), true);
}
