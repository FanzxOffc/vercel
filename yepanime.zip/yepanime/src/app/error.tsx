"use client";

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faRotateRight, faTriangleExclamation } from "@fortawesome/free-solid-svg-icons";
import { buttonClass, cardClass } from "@/lib/ui";

interface ErrorPageProps {
  reset: () => void;
}

export default function ErrorPage({ reset }: ErrorPageProps) {
  return (
    <div className="mx-auto flex min-h-[50vh] w-full max-w-md items-center">
      <div className={`${cardClass} w-full space-y-4 p-6 text-center`}>
        <FontAwesomeIcon icon={faTriangleExclamation} className="text-4xl text-accent" />
        <h1 className="text-lg font-semibold text-white">Terjadi kesalahan</h1>
        <p className="text-sm text-muted">
          Data tidak dapat dimuat saat ini. Silakan coba lagi sebentar lagi.
        </p>
        <button type="button" onClick={reset} className={buttonClass("primary")}>
          <FontAwesomeIcon icon={faRotateRight} />
          Coba Lagi
        </button>
      </div>
    </div>
  );
}
