import { getHomeAnime } from "@/lib/scraper";
import type { HomeAnime } from "@/lib/types";
import { HomeFeed } from "@/components/home-feed";
import { SearchBox } from "@/components/search-box";

export const maxDuration = 30;

export default async function HomePage() {
  const items = await getHomeAnime(1).catch((): HomeAnime[] => []);

  return (
    <div className="space-y-12">
      <section className="space-y-5 pt-4 text-center">
        <p
          className="mx-auto inline-flex rounded-full border border-red-500/20 bg-red-500/10 px-3 py-1 font-mono text-xs text-accent"
          data-aos="fade-up"
        >
          Subtitle Indonesia
        </p>
        <h1
          className="text-4xl font-bold leading-tight text-white sm:text-5xl"
          data-aos="fade-up"
          data-aos-delay="80"
        >
          Nonton Anime <span className="text-accent">Tanpa Ribet.</span>
        </h1>
        <p
          className="mx-auto max-w-xl text-sm leading-relaxed text-muted sm:text-base"
          data-aos="fade-up"
          data-aos-delay="160"
        >
          Temukan, tonton, dan unduh anime favoritmu dengan tampilan yang ringan dan nyaman di
          ponsel.
        </p>
        <div className="mx-auto max-w-xl" data-aos="fade-up" data-aos-delay="240">
          <SearchBox />
        </div>
      </section>

      <section className="space-y-5" aria-labelledby="judul-update">
        <div className="flex items-center gap-3" data-aos="fade-up">
          <span className="h-6 w-1 rounded-full bg-accent" />
          <h2 id="judul-update" className="text-xl font-semibold text-white">
            Update Terbaru
          </h2>
        </div>
        <HomeFeed initialItems={items} />
      </section>
    </div>
  );
}
