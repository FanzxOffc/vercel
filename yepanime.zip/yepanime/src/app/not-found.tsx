import Link from "next/link";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faShieldHalved } from "@fortawesome/free-solid-svg-icons";
import { buttonClass, cardClass } from "@/lib/ui";

export default function NotFound() {
  return (
    <div className="mx-auto flex min-h-[60vh] w-full max-w-xl items-center">
      <div className={`${cardClass} w-full space-y-6 p-6 font-mono`} data-aos="fade-up">
        <div className="flex items-center gap-3 text-green-400">
          <FontAwesomeIcon icon={faShieldHalved} className="text-3xl" />
          <span className="text-sm">yep-shield v1.0</span>
        </div>
        <div className="space-y-1 text-sm text-green-400">
          <p>$ cari --halaman</p>
          <p>galat 404: halaman tidak ditemukan</p>
          <p>$ status --keamanan</p>
          <p>zona aman terdeteksi. tidak ada ancaman.</p>
          <p>
            $ <span className="animate-pulse">_</span>
          </p>
        </div>
        <Link href="/" className={buttonClass("primary", "w-full sm:w-auto")}>
          RETURN TO SAFE ZONE
        </Link>
      </div>
    </div>
  );
}
