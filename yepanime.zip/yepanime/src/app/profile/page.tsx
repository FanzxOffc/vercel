import type { Metadata } from "next";
import Link from "next/link";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faClockRotateLeft, faShieldHalved, faUser } from "@fortawesome/free-solid-svg-icons";
import { buttonClass, cardClass } from "@/lib/ui";

export const metadata: Metadata = { title: "Profil" };

export default function ProfilePage() {
  return (
    <div className="mx-auto max-w-md space-y-6">
      <div className={`${cardClass} space-y-4 p-6 text-center`} data-aos="fade-up">
        <span className="mx-auto flex h-20 w-20 items-center justify-center rounded-full border border-red-500/20 bg-red-500/10 text-3xl text-accent">
          <FontAwesomeIcon icon={faUser} />
        </span>
        <h1 className="text-xl font-semibold text-white">Profil Tamu</h1>
        <p className="text-sm leading-relaxed text-muted">
          YepAnime tidak memerlukan akun. Riwayat tontonanmu hanya tersimpan di perangkat ini.
        </p>
      </div>
      <div className="grid gap-3" data-aos="fade-up" data-aos-delay="100">
        <Link href="/history" className={buttonClass("secondary")}>
          <FontAwesomeIcon icon={faClockRotateLeft} />
          Riwayat Tontonan
        </Link>
        <Link href="/privasi" className={buttonClass("secondary")}>
          <FontAwesomeIcon icon={faShieldHalved} />
          Kebijakan Privasi
        </Link>
      </div>
    </div>
  );
}
