import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { DownloadList } from "@/components/download-list";
import { getDownload } from "@/lib/scraper";
import { isValidSlug, upstreamUrl } from "@/lib/urls";

export const maxDuration = 30;

export const metadata: Metadata = { title: "Unduh Batch" };

interface PageProps {
  params: { slug: string };
}

export default async function BatchPage({ params }: PageProps) {
  if (!isValidSlug(params.slug)) {
    notFound();
  }

  const data = await getDownload(upstreamUrl("batch", params.slug)).catch(() => null);
  if (!data) {
    notFound();
  }

  return (
    <div className="space-y-8">
      <h1 className="text-xl font-bold leading-snug text-white sm:text-2xl" data-aos="fade-up">
        {data.title}
      </h1>
      <DownloadList groups={data.downloads} />
    </div>
  );
}
