import type { Metadata } from "next";
import { cardClass } from "@/lib/ui";

export const metadata: Metadata = { title: "Kebijakan Privasi" };

interface PolicySection {
  title: string;
  body: string;
}

const sections: PolicySection[] = [
  {
    title: "Data yang kami kumpulkan",
    body: "YepAnime tidak meminta pendaftaran akun dan tidak mengumpulkan data pribadi seperti nama, email, atau nomor telepon.",
  },
  {
    title: "Penyimpanan di perangkat",
    body: "Riwayat tontonan disimpan secara lokal di peramban kamu melalui penyimpanan lokal. Data ini tidak dikirim ke server kami dan dapat dihapus kapan saja melalui halaman Riwayat.",
  },
  {
    title: "Konten pihak ketiga",
    body: "Video dan tautan unduhan disediakan oleh pihak ketiga. Penyedia tersebut dapat menerapkan kebijakan privasi mereka sendiri. Kami menyarankan kamu membacanya sebelum menggunakan layanan mereka.",
  },
  {
    title: "Log teknis",
    body: "Penyedia hosting dapat mencatat data teknis standar seperti alamat IP dan waktu akses untuk menjaga keamanan dan mencegah penyalahgunaan layanan.",
  },
  {
    title: "Perubahan kebijakan",
    body: "Kebijakan ini dapat diperbarui sewaktu-waktu. Perubahan akan ditampilkan di halaman ini.",
  },
];

export default function PrivacyPage() {
  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <h1 className="text-2xl font-bold text-white" data-aos="fade-up">
        Kebijakan Privasi
      </h1>
      {sections.map((section) => (
        <section key={section.title} className={`${cardClass} space-y-2 p-5`} data-aos="fade-up">
          <h2 className="text-base font-semibold text-white">{section.title}</h2>
          <p className="text-sm leading-relaxed text-muted">{section.body}</p>
        </section>
      ))}
    </div>
  );
}
