import { cache } from "react";
import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faBoxArchive, faFilm, faPlay, faStar } from "@fortawesome/free-solid-svg-icons";
import { StatusBadge } from "@/components/badges";
import { getDetail } from "@/lib/scraper";
import { buttonClass, cardClass } from "@/lib/ui";
import { episodeLabel, internalPath, isValidSlug, upstreamUrl } from "@/lib/urls";

export const maxDuration = 30;

interface PageProps {
  params: { slug: string };
}

const loadDetail = cache(async (slug: string) => getDetail(upstreamUrl("anime", slug)).catch(() => null));

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const detail = isValidSlug(params.slug) ? await loadDetail(params.slug) : null;
  return { title: detail ? detail.title : "Anime" };
}

export default async function AnimeDetailPage({ params }: PageProps) {
  if (!isValidSlug(params.slug)) {
    notFound();
  }

  const detail = await loadDetail(params.slug);
  if (!detail) {
    notFound();
  }

  const episodes = detail.episodes.filter((episode) => episode.link.includes("/episode/"));
  const batch = detail.episodes.find((episode) => episode.link.includes("/batch/"));
  const firstEpisode = episodes[episodes.length - 1];
  const status = detail.info["Status"];
  const rating = detail.info["Skor"];
  const infoEntries = Object.entries(detail.info);

  return (
    <div className="space-y-10">
      <section className="grid gap-6 md:grid-cols-[240px_1fr]">
        <div className="mx-auto w-44 sm:w-52 md:mx-0 md:w-full" data-aos="fade-up">
          <div className={`${cardClass} relative aspect-[3/4] w-full bg-[#0f0f0f]`}>
            {detail.thumb ? (
              <Image
                src={detail.thumb}
                alt={detail.title}
                fill
                unoptimized
                priority
                sizes="(max-width: 768px) 208px, 240px"
                referrerPolicy="no-referrer"
                className="object-cover"
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center text-4xl text-muted">
                <FontAwesomeIcon icon={faFilm} />
              </div>
            )}
          </div>
        </div>

        <div className="space-y-4 text-center md:text-left" data-aos="fade-up" data-aos-delay="100">
          <h1 className="text-2xl font-bold leading-snug text-white sm:text-3xl">{detail.title}</h1>
          <div className="flex flex-wrap items-center justify-center gap-2 md:justify-start">
            {status ? <StatusBadge status={status} /> : null}
            {rating ? (
              <span className="inline-flex items-center gap-2 rounded-full border border-yellow-500/20 bg-yellow-500/10 px-3 py-1 font-mono text-xs text-yellow-400">
                <FontAwesomeIcon icon={faStar} />
                {rating}
              </span>
            ) : null}
          </div>
          <div className="flex flex-wrap justify-center gap-3 pt-2 md:justify-start">
            {firstEpisode ? (
              <Link href={internalPath(firstEpisode.link)} className={buttonClass("primary")}>
                <FontAwesomeIcon icon={faPlay} />
                Mulai Nonton
              </Link>
            ) : null}
            {batch ? (
              <Link href={internalPath(batch.link)} className={buttonClass("info")}>
                <FontAwesomeIcon icon={faBoxArchive} />
                Unduh Batch
              </Link>
            ) : null}
          </div>
        </div>
      </section>

      {infoEntries.length > 0 ? (
        <section className="space-y-4" aria-labelledby="judul-info">
          <div className="flex items-center gap-3" data-aos="fade-up">
            <span className="h-6 w-1 rounded-full bg-accent" />
            <h2 id="judul-info" className="text-xl font-semibold text-white">
              Informasi
            </h2>
          </div>
          <dl className={`${cardClass} divide-y divide-white/5 font-mono text-xs sm:text-sm`} data-aos="fade-up">
            {infoEntries.map(([key, value]) => (
              <div key={key} className="grid grid-cols-[110px_1fr] gap-3 px-4 py-3 sm:grid-cols-[170px_1fr]">
                <dt className="text-muted">{key}</dt>
                <dd className="min-w-0 break-words text-ink">{value}</dd>
              </div>
            ))}
          </dl>
        </section>
      ) : null}

      {detail.synopsis ? (
        <section className="space-y-4" aria-labelledby="judul-sinopsis">
          <div className="flex items-center gap-3" data-aos="fade-up">
            <span className="h-6 w-1 rounded-full bg-accent" />
            <h2 id="judul-sinopsis" className="text-xl font-semibold text-white">
              Sinopsis
            </h2>
          </div>
          <p className="text-sm leading-relaxed text-muted sm:text-base" data-aos="fade-up">
            {detail.synopsis}
          </p>
        </section>
      ) : null}

      <section className="space-y-4" aria-labelledby="judul-episode">
        <div className="flex items-center gap-3" data-aos="fade-up">
          <span className="h-6 w-1 rounded-full bg-accent" />
          <h2 id="judul-episode" className="text-xl font-semibold text-white">
            Daftar Episode
          </h2>
        </div>
        {episodes.length === 0 ? (
          <p className={`${cardClass} p-6 text-center text-sm text-muted`}>
            Episode belum tersedia.
          </p>
        ) : (
          <div className="max-h-[28rem] overflow-y-auto pr-1" data-aos="fade-up">
            <div className="grid grid-cols-3 gap-2 sm:grid-cols-5 md:grid-cols-6">
              {episodes.map((episode) => (
                <Link
                  key={episode.link}
                  href={internalPath(episode.link)}
                  title={episode.title}
                  className={buttonClass("secondary", "!px-2 text-xs")}
                >
                  {episodeLabel(episode.title)}
                </Link>
              ))}
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
