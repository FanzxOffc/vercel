import { Suspense } from "react";
import type { Metadata } from "next";
import { SearchView } from "@/components/search-view";
import { SkeletonGrid } from "@/components/skeleton";

export const metadata: Metadata = { title: "Cari Anime" };

export default function SearchPage() {
  return (
    <Suspense fallback={<SkeletonGrid count={10} />}>
      <SearchView />
    </Suspense>
  );
}
