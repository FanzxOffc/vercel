import { SkeletonGrid } from "@/components/skeleton";

export default function Loading() {
  return (
    <div className="space-y-6" aria-busy="true" aria-label="Memuat">
      <div className="h-8 w-48 animate-pulse rounded-full bg-white/5" />
      <SkeletonGrid count={10} />
    </div>
  );
}
