"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faClockRotateLeft, faPlay, faTrash } from "@fortawesome/free-solid-svg-icons";
import type { HistoryEntry } from "@/lib/types";
import { clearHistory, readHistory } from "@/lib/history";
import { buttonClass, cardClass } from "@/lib/ui";

const formatTime = (value: number): string =>
  new Date(value).toLocaleString("id-ID", { dateStyle: "medium", timeStyle: "short" });

export function HistoryList() {
  const [entries, setEntries] = useState<HistoryEntry[] | null>(null);

  useEffect(() => {
    setEntries(readHistory());
  }, []);

  const handleClear = () => {
    clearHistory();
    setEntries([]);
  };

  if (entries === null) {
    return <div className="h-40 animate-pulse rounded-xl bg-white/5" />;
  }

  if (entries.length === 0) {
    return (
      <div className={`${cardClass} space-y-3 p-8 text-center`}>
        <FontAwesomeIcon icon={faClockRotateLeft} className="text-3xl text-accent" />
        <p className="text-sm text-muted">Belum ada riwayat tontonan di perangkat ini.</p>
        <Link href="/" className={buttonClass("primary")}>
          Jelajahi Anime
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <ul className="space-y-3">
        {entries.map((entry) => (
          <li key={entry.slug} data-aos="fade-up">
            <Link
              href={`/episode/${entry.slug}`}
              className={`${cardClass} flex min-h-[64px] items-center gap-4 p-4 transition-colors duration-300 hover:border-red-500/30`}
            >
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-accent text-white">
                <FontAwesomeIcon icon={faPlay} className="text-sm" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="line-clamp-2 block text-sm font-medium text-ink">
                  {entry.title}
                </span>
                <span className="block font-mono text-xs text-muted">
                  {formatTime(entry.watchedAt)}
                </span>
              </span>
            </Link>
          </li>
        ))}
      </ul>
      <button type="button" onClick={handleClear} className={buttonClass("danger")}>
        <FontAwesomeIcon icon={faTrash} />
        Hapus Riwayat
      </button>
    </div>
  );
}
