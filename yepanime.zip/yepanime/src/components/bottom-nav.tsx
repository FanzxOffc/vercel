"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { navItems } from "@/lib/nav";

const isActive = (pathname: string, href: string): boolean =>
  href === "/" ? pathname === "/" : pathname.startsWith(href);

export function BottomNav() {
  const pathname = usePathname();

  return (
    <nav
      className="safe-bottom fixed inset-x-0 bottom-0 z-40 border-t border-red-500/20 bg-base/90 backdrop-blur-md md:hidden"
      aria-label="Navigasi bawah"
    >
      <ul className="mx-auto grid max-w-md grid-cols-4">
        {navItems.map((item) => {
          const active = isActive(pathname, item.href);
          return (
            <li key={item.href}>
              <Link
                href={item.href}
                aria-current={active ? "page" : undefined}
                className={`flex min-h-[56px] flex-col items-center justify-center gap-1 text-[11px] transition-colors duration-300 ${
                  active ? "text-accent" : "text-muted hover:text-white"
                }`}
              >
                <FontAwesomeIcon icon={item.icon} className="text-lg" />
                {item.label}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
