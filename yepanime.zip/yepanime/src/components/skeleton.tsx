import { cardClass, gridClass } from "@/lib/ui";

export function SkeletonCard() {
  return (
    <div className={`${cardClass} animate-pulse`}>
      <div className="aspect-[3/4] w-full bg-white/5" />
      <div className="space-y-2 p-3">
        <div className="h-3 w-full rounded-full bg-white/5" />
        <div className="h-3 w-2/3 rounded-full bg-white/5" />
      </div>
    </div>
  );
}

interface SkeletonGridProps {
  count: number;
}

export function SkeletonGrid({ count }: SkeletonGridProps) {
  return (
    <div className={gridClass}>
      {Array.from({ length: count }, (_, index) => (
        <SkeletonCard key={index} />
      ))}
    </div>
  );
}
