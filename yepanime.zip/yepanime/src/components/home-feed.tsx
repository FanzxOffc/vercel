"use client";

import { useCallback, useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faChevronDown, faCircleNotch } from "@fortawesome/free-solid-svg-icons";
import type { HomeAnime } from "@/lib/types";
import { fetchJson } from "@/lib/client";
import { buttonClass, gridClass } from "@/lib/ui";
import { AnimeCard } from "./anime-card";

interface HomeFeedProps {
  initialItems: HomeAnime[];
}

export function HomeFeed({ initialItems }: HomeFeedProps) {
  const [items, setItems] = useState<HomeAnime[]>(initialItems);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [exhausted, setExhausted] = useState(false);
  const [failed, setFailed] = useState(false);

  const loadMore = useCallback(async () => {
    setLoading(true);
    setFailed(false);
    try {
      const nextPage = page + 1;
      const data = await fetchJson<HomeAnime[]>(`/api/home?page=${nextPage}`);
      const seen = new Set(items.map((item) => item.link));
      const fresh = data.filter((item) => !seen.has(item.link));
      setItems([...items, ...fresh]);
      setPage(nextPage);
      if (fresh.length === 0) {
        setExhausted(true);
      }
    } catch {
      setFailed(true);
    } finally {
      setLoading(false);
    }
  }, [items, page]);

  if (items.length === 0) {
    return (
      <p className="rounded-xl border border-red-500/10 bg-surface p-6 text-center text-sm text-muted">
        Pembaruan terbaru belum dapat dimuat. Coba muat ulang halaman beberapa saat lagi.
      </p>
    );
  }

  return (
    <div className="space-y-6">
      <div className={gridClass}>
        {items.map((item, index) => (
          <AnimeCard
            key={item.link}
            title={item.title}
            link={item.link}
            thumb={item.thumb}
            badge={item.episode}
            subtitle={item.date}
            index={index}
          />
        ))}
      </div>
      <div className="flex flex-col items-center gap-3">
        {exhausted ? (
          <p className="text-sm text-muted">Semua pembaruan sudah ditampilkan.</p>
        ) : (
          <button
            type="button"
            onClick={loadMore}
            disabled={loading}
            className={buttonClass("secondary", "min-w-[200px]")}
          >
            <FontAwesomeIcon icon={loading ? faCircleNotch : faChevronDown} spin={loading} />
            {loading ? "Memuat..." : "Muat Lebih Banyak"}
          </button>
        )}
        {failed ? (
          <p className="text-sm text-red-400">Gagal memuat data. Silakan coba lagi.</p>
        ) : null}
      </div>
    </div>
  );
}
