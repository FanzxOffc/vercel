"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faMagnifyingGlass, faTriangleExclamation } from "@fortawesome/free-solid-svg-icons";
import type { SearchResult } from "@/lib/types";
import { fetchJson } from "@/lib/client";
import { cardClass, gridClass } from "@/lib/ui";
import { AnimeCard } from "./anime-card";
import { SearchBox } from "./search-box";
import { SkeletonGrid } from "./skeleton";

type SearchStatus = "idle" | "loading" | "error" | "done";

interface SearchState {
  status: SearchStatus;
  results: SearchResult[];
}

export function SearchView() {
  const params = useSearchParams();
  const query = (params.get("q") ?? "").trim();
  const [state, setState] = useState<SearchState>({ status: "idle", results: [] });

  useEffect(() => {
    if (!query) {
      setState({ status: "idle", results: [] });
      return undefined;
    }

    const controller = new AbortController();
    setState({ status: "loading", results: [] });

    fetchJson<SearchResult[]>(`/api/search?q=${encodeURIComponent(query)}`, controller.signal)
      .then((results) => setState({ status: "done", results }))
      .catch((error: unknown) => {
        if (error instanceof DOMException && error.name === "AbortError") {
          return;
        }
        setState({ status: "error", results: [] });
      });

    return () => controller.abort();
  }, [query]);

  return (
    <div className="space-y-6">
      <div data-aos="fade-up">
        <SearchBox initialValue={query} />
      </div>

      {state.status === "idle" ? (
        <div className={`${cardClass} space-y-3 p-8 text-center`}>
          <FontAwesomeIcon icon={faMagnifyingGlass} className="text-3xl text-accent" />
          <p className="text-sm text-muted">Ketik judul anime untuk mulai mencari.</p>
        </div>
      ) : null}

      {state.status === "loading" ? <SkeletonGrid count={10} /> : null}

      {state.status === "error" ? (
        <div className={`${cardClass} space-y-3 p-8 text-center`}>
          <FontAwesomeIcon icon={faTriangleExclamation} className="text-3xl text-accent" />
          <p className="text-sm text-muted">Pencarian gagal dimuat. Silakan coba lagi.</p>
        </div>
      ) : null}

      {state.status === "done" && state.results.length === 0 ? (
        <div className={`${cardClass} space-y-3 p-8 text-center`}>
          <FontAwesomeIcon icon={faMagnifyingGlass} className="text-3xl text-accent" />
          <h2 className="text-lg font-semibold text-white">Anime tidak ditemukan</h2>
          <p className="text-sm text-muted">Coba gunakan kata kunci lain atau periksa ejaan judul.</p>
        </div>
      ) : null}

      {state.status === "done" && state.results.length > 0 ? (
        <section className="space-y-4">
          <h1 className="text-lg font-semibold text-white">
            Hasil pencarian: <span className="text-accent">{query}</span>
          </h1>
          <div className={gridClass}>
            {state.results.map((result, index) => (
              <AnimeCard
                key={result.link}
                title={result.title}
                link={result.link}
                thumb={result.thumb}
                badge={result.info["Rating"]}
                subtitle={result.info["Status"]}
                index={index}
              />
            ))}
          </div>
        </section>
      ) : null}
    </div>
  );
}
