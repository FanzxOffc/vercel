"use client";

import { useEffect } from "react";
import { pushHistory } from "@/lib/history";

interface HistoryRecorderProps {
  slug: string;
  title: string;
}

export function HistoryRecorder({ slug, title }: HistoryRecorderProps) {
  useEffect(() => {
    pushHistory({ slug, title, watchedAt: Date.now() });
  }, [slug, title]);

  return null;
}
