import { badgeClasses } from "@/lib/ui";

interface StatusBadgeProps {
  status: string;
}

export function StatusBadge({ status }: StatusBadgeProps) {
  const ongoing = /ongoing|berlangsung/i.test(status);
  return (
    <span className={ongoing ? badgeClasses.ongoing : badgeClasses.completed}>
      {ongoing ? "Berlangsung" : "Selesai"}
    </span>
  );
}

interface EpisodeBadgeProps {
  label: string;
  className?: string;
}

export function EpisodeBadge({ label, className = "" }: EpisodeBadgeProps) {
  return <span className={`${badgeClasses.episode} ${className}`}>{label}</span>;
}
