import Link from "next/link";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faMagnifyingGlass } from "@fortawesome/free-solid-svg-icons";
import { navItems } from "@/lib/nav";
import { buttonClass } from "@/lib/ui";

export function Navbar() {
  return (
    <header className="sticky top-0 z-40 border-b border-red-500/20 bg-base/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between gap-4 px-4">
        <Link
          href="/"
          className="flex min-h-[44px] items-center text-xl font-bold tracking-tight"
          aria-label="Beranda YepAnime"
        >
          <span className="text-white">Yep</span>
          <span className="text-accent">Anime</span>
        </Link>
        <nav className="hidden items-center gap-1 md:flex" aria-label="Navigasi utama">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="flex min-h-[44px] items-center gap-2 rounded-full px-4 text-sm text-muted transition-colors duration-300 hover:bg-white/5 hover:text-white"
            >
              <FontAwesomeIcon icon={item.icon} />
              {item.label}
            </Link>
          ))}
        </nav>
        <Link
          href="/search"
          className={buttonClass("secondary", "w-11 !px-0 md:hidden")}
          aria-label="Cari anime"
        >
          <FontAwesomeIcon icon={faMagnifyingGlass} />
        </Link>
      </div>
    </header>
  );
}
