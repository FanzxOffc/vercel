"use client";

import { useEffect, useState } from "react";
import type { FormEvent } from "react";
import { useRouter } from "next/navigation";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faMagnifyingGlass } from "@fortawesome/free-solid-svg-icons";
import { buttonClass, cardClass, inputClass } from "@/lib/ui";

interface SearchBoxProps {
  initialValue?: string;
}

export function SearchBox({ initialValue = "" }: SearchBoxProps) {
  const router = useRouter();
  const [value, setValue] = useState(initialValue);

  useEffect(() => {
    setValue(initialValue);
  }, [initialValue]);

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const query = value.trim();
    if (!query) {
      return;
    }
    router.push(`/search?q=${encodeURIComponent(query)}`);
  };

  return (
    <div className={`${cardClass} p-3`}>
      <form onSubmit={submit} className="flex flex-col gap-3 sm:flex-row" role="search">
        <label htmlFor="kolom-cari" className="sr-only">
          Cari anime
        </label>
        <input
          id="kolom-cari"
          type="search"
          value={value}
          onChange={(event) => setValue(event.target.value)}
          placeholder="Cari judul anime..."
          maxLength={100}
          autoComplete="off"
          className={inputClass}
        />
        <button type="submit" className={buttonClass("primary", "sm:w-auto")}>
          <FontAwesomeIcon icon={faMagnifyingGlass} />
          Cari
        </button>
      </form>
    </div>
  );
}
