"use client";

import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faFilm } from "@fortawesome/free-solid-svg-icons";
import { internalPath } from "@/lib/urls";
import { cardClass } from "@/lib/ui";
import { EpisodeBadge } from "./badges";

interface AnimeCardProps {
  title: string;
  link: string;
  thumb: string;
  badge?: string;
  subtitle?: string;
  index?: number;
}

export function AnimeCard({ title, link, thumb, badge, subtitle, index = 0 }: AnimeCardProps) {
  return (
    <div data-aos="fade-up" data-aos-delay={(index % 5) * 60} className="h-full">
      <motion.div
        whileHover={{ y: -4 }}
        whileTap={{ scale: 0.98 }}
        transition={{ duration: 0.25, ease: "easeOut" }}
        className="h-full"
      >
        <Link href={internalPath(link)} className={`${cardClass} group flex h-full flex-col`}>
          <div className="relative aspect-[3/4] w-full bg-[#0f0f0f]">
            {thumb ? (
              <Image
                src={thumb}
                alt={title}
                fill
                unoptimized
                sizes="(max-width: 640px) 50vw, 20vw"
                referrerPolicy="no-referrer"
                className="object-cover transition-transform duration-500 group-hover:scale-105"
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center text-3xl text-muted">
                <FontAwesomeIcon icon={faFilm} />
              </div>
            )}
            <div className="absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t from-surface to-transparent" />
            {badge ? <EpisodeBadge label={badge} className="absolute left-2 top-2" /> : null}
          </div>
          <div className="flex flex-1 flex-col gap-1 p-3">
            <h3 className="line-clamp-2 min-h-[2.5rem] text-sm font-medium text-ink">{title}</h3>
            {subtitle ? <p className="font-mono text-xs text-muted">{subtitle}</p> : null}
          </div>
        </Link>
      </motion.div>
    </div>
  );
}
