import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faDownload } from "@fortawesome/free-solid-svg-icons";
import type { DownloadGroup } from "@/lib/types";
import { isSafeHttpUrl } from "@/lib/urls";
import { buttonClass, cardClass } from "@/lib/ui";

interface DownloadListProps {
  groups: DownloadGroup[];
}

export function DownloadList({ groups }: DownloadListProps) {
  const visible = groups
    .map((group) => ({ ...group, links: group.links.filter((link) => isSafeHttpUrl(link.url)) }))
    .filter((group) => group.links.length > 0);

  return (
    <section className="space-y-4" aria-labelledby="judul-unduh">
      <div className="flex items-center gap-3" data-aos="fade-up">
        <span className="h-6 w-1 rounded-full bg-accent" />
        <h2 id="judul-unduh" className="text-xl font-semibold text-white">
          Unduh Episode
        </h2>
      </div>
      {visible.length === 0 ? (
        <p className={`${cardClass} p-6 text-center text-sm text-muted`}>
          Tautan unduhan belum tersedia.
        </p>
      ) : (
        <div className="space-y-3">
          {visible.map((group) => (
            <div key={group.format} className={`${cardClass} space-y-3 p-4`} data-aos="fade-up">
              <h3 className="font-mono text-xs text-accent">{group.format}</h3>
              <div className="flex flex-wrap gap-2">
                {group.links.map((link) => (
                  <a
                    key={`${group.format}-${link.provider}-${link.url}`}
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer nofollow"
                    className={buttonClass("secondary", "text-xs")}
                  >
                    <FontAwesomeIcon icon={faDownload} />
                    {link.provider}
                  </a>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
