"use client";

import { useCallback, useMemo, useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCircleNotch, faCirclePlay } from "@fortawesome/free-solid-svg-icons";
import type { MirrorGroup, MirrorLink, ResolveResult } from "@/lib/types";
import { isSafeHttpUrl, normalizeQuality } from "@/lib/urls";
import { buttonClass, cardClass } from "@/lib/ui";

interface EpisodePlayerProps {
  episodeUrl: string;
  defaultStream: string | null;
  isMaintenance: boolean;
  mirrors: MirrorGroup[];
}

interface QualityGroup {
  quality: string;
  links: MirrorLink[];
}

export function EpisodePlayer({
  episodeUrl,
  defaultStream,
  isMaintenance,
  mirrors,
}: EpisodePlayerProps) {
  const groups = useMemo<QualityGroup[]>(
    () => mirrors.map((mirror) => ({ quality: normalizeQuality(mirror.quality), links: mirror.links })),
    [mirrors]
  );
  const [src, setSrc] = useState<string | null>(
    defaultStream && isSafeHttpUrl(defaultStream) ? defaultStream : null
  );
  const [activeQuality, setActiveQuality] = useState<string | null>(null);
  const [activeKey, setActiveKey] = useState<string | null>(null);
  const [pendingKey, setPendingKey] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const currentGroup = groups.find((group) => group.quality === activeQuality) ?? null;

  const play = useCallback(
    async (quality: string, link: MirrorLink) => {
      const key = `${quality}-${link.provider}`;
      setPendingKey(key);
      setMessage(null);
      try {
        const res = await fetch("/api/resolve", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ url: episodeUrl, encoded: link.encoded }),
        });
        if (!res.ok) {
          throw new Error(`HTTP ${res.status}`);
        }
        const data = (await res.json()) as ResolveResult;
        if (data.iframe && isSafeHttpUrl(data.iframe)) {
          setSrc(data.iframe);
          setActiveKey(key);
        } else {
          setMessage("Sumber video tidak tersedia. Coba server lain.");
        }
      } catch {
        setMessage("Gagal memuat video. Coba pilih kualitas atau server lain.");
      } finally {
        setPendingKey(null);
      }
    },
    [episodeUrl]
  );

  const selectQuality = (group: QualityGroup) => {
    setActiveQuality(group.quality);
    const first = group.links[0];
    if (first) {
      void play(group.quality, first);
    }
  };

  return (
    <div className="space-y-4">
      <div className={`${cardClass} relative aspect-video w-full bg-black`}>
        {src ? (
          <iframe
            key={src}
            src={src}
            title="Pemutar video"
            className="absolute inset-0 h-full w-full border-0"
            allowFullScreen
            referrerPolicy="no-referrer"
          />
        ) : (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 p-6 text-center text-muted">
            <FontAwesomeIcon icon={faCirclePlay} className="text-4xl text-accent" />
            <p className="max-w-xs text-sm">
              {isMaintenance
                ? "Server utama sedang dalam pemeliharaan. Pilih kualitas di bawah untuk memutar dari server lain."
                : "Pilih kualitas di bawah untuk mulai menonton."}
            </p>
          </div>
        )}
        {pendingKey ? (
          <div className="absolute inset-0 flex items-center justify-center bg-black/70">
            <FontAwesomeIcon icon={faCircleNotch} spin className="text-3xl text-accent" />
          </div>
        ) : null}
      </div>

      {groups.length > 0 ? (
        <div className={`${cardClass} space-y-4 p-4`}>
          <div className="space-y-2">
            <p className="font-mono text-xs text-muted">Kualitas</p>
            <div className="flex flex-wrap gap-2">
              {groups.map((group) => (
                <button
                  key={group.quality}
                  type="button"
                  onClick={() => selectQuality(group)}
                  disabled={pendingKey !== null}
                  className={buttonClass(
                    group.quality === activeQuality ? "primary" : "secondary",
                    "font-mono text-xs"
                  )}
                >
                  {group.quality}
                </button>
              ))}
            </div>
          </div>

          {currentGroup ? (
            <div className="space-y-2">
              <p className="font-mono text-xs text-muted">Server</p>
              <div className="flex flex-wrap gap-2">
                {currentGroup.links.map((link) => {
                  const key = `${currentGroup.quality}-${link.provider}`;
                  return (
                    <button
                      key={key}
                      type="button"
                      onClick={() => void play(currentGroup.quality, link)}
                      disabled={pendingKey !== null}
                      className={buttonClass(key === activeKey ? "success" : "secondary", "text-xs")}
                    >
                      {link.provider}
                    </button>
                  );
                })}
              </div>
            </div>
          ) : null}
        </div>
      ) : null}

      {message ? <p className="text-sm text-red-400">{message}</p> : null}
    </div>
  );
}
