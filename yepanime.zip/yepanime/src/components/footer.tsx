import Link from "next/link";

export function Footer() {
  return (
    <footer className="border-t border-red-500/10 pb-24 pt-8 md:pb-8">
      <div className="mx-auto flex w-full max-w-6xl flex-col items-center gap-3 px-4 text-center text-xs text-muted">
        <p>
          <span className="text-white">Yep</span>
          <span className="text-accent">Anime</span> - Nonton anime tanpa ribet.
        </p>
        <p className="max-w-md">
          YepAnime tidak menyimpan file video apa pun. Seluruh konten berasal dari pihak ketiga.
        </p>
        <Link
          href="/privasi"
          className="flex min-h-[44px] items-center text-muted underline-offset-4 transition-colors duration-300 hover:text-accent hover:underline"
        >
          Kebijakan Privasi
        </Link>
      </div>
    </footer>
  );
}
